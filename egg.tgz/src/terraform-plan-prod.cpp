// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Plan prod changes"); }
int main(){
  announce();
  return lionss_run_workload("terraform-plan-prod");
}
