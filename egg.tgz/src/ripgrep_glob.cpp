// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Glob-filtered grep"); }
int main(){
  announce();
  return lionss_run_workload("ripgrep_glob");
}
