// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Animate blue heron"); }
int main(){
  announce();
  return lionss_run_workload("BlueHeron");
}
