// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Convolve HRTF\n", stdout);
  return lionss_run_workload("hrtfconvolve");
}
