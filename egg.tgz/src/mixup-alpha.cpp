// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply mixup\n", stdout);
  return lionss_run_workload("mixup-alpha");
}
