// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Route ashford crossing"); }
int main(){
  announce();
  return lionss_run_workload("ashford");
}
